namespace WPFWBackend.Features.Blog.GetBlog;
public sealed record class GetBlogResponse(public int Id, public string Titel, public string Inhoud, public DateOnly Publicatiedatum);
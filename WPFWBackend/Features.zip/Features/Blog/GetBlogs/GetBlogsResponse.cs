namespace WPFWBackend.Features.Blog.GetBlogs;
public sealed record class GetBlogsResponse(public int Id, public string Titel, public string Inhoud, public DateOnly Publicatiedatum);